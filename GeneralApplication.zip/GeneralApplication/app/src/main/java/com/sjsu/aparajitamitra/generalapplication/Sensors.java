package com.sjsu.aparajitamitra.generalapplication;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;


public class Sensors extends AppCompatActivity implements SensorEventListener {

    private static final int MY_PERMISSIONS_FINE_LOCATION = 1;
    private static final int MY_PERMISSIONS_COARSE_LOCATION = 1;
    private static final int MY_PERMISSIONS_VIBRATE = 1;
    public Vibrator v;
    SQLiteDatabase db;
    private float lastX, lastY, lastZ;
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private float deltaXMax = 0;
    private float deltaYMax = 0;
    private float deltaZMax = 0;
    private float deltaX = 0;
    private float deltaY = 0;
    private float deltaZ = 0;
    private float vibrateThreshold = 0;
    private TextView currentX, currentY, currentZ, maxX, maxY, maxZ, alert;



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensors);




        System.out.println("Test");
        db = openOrCreateDatabase("SensorDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS sensor(event_date VARCHAR,x VARCHAR,y VARCHAR,z VARCHAR);");

        db.execSQL("CREATE TABLE IF NOT EXISTS movement(event_date VARCHAR,mesaage VARCHAR,x VARCHAR,y VARCHAR,z VARCHAR);");


        initializeViews();

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null) {


            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_STATUS_ACCURACY_HIGH);
            vibrateThreshold = accelerometer.getMaximumRange() / 20;
        } else {

            ActivityCompat.requestPermissions((Activity) super.getBaseContext(),
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    MY_PERMISSIONS_FINE_LOCATION);
            ActivityCompat.requestPermissions((Activity) super.getBaseContext(),
                    new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},
                    MY_PERMISSIONS_COARSE_LOCATION);

            ActivityCompat.requestPermissions((Activity) super.getBaseContext(),
                    new String[]{Manifest.permission.VIBRATE},
                    MY_PERMISSIONS_VIBRATE);

        }


        v = (Vibrator) this.getSystemService(Context.VIBRATOR_SERVICE);

    }

    public void initializeViews() {


        currentX = (TextView) findViewById(R.id.currentX);
        currentY = (TextView) findViewById(R.id.currentY);
        currentZ = (TextView) findViewById(R.id.currentZ);

        maxX = (TextView) findViewById(R.id.maxX);
        maxY = (TextView) findViewById(R.id.maxY);
        maxZ = (TextView) findViewById(R.id.maxZ);
        alert = (TextView) findViewById(R.id.textView);
    }


    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI);
    }

    //onPause() unregister the accelerometer for stop listening the events
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    public void onSensorChanged(SensorEvent event) {



        db.execSQL("INSERT INTO sensor VALUES('" + event.timestamp + "','" + event.values[0] +
                "','" + event.values[1] + "','" + event.values[2] + "');");

        displayCleanValues();

        displayCurrentValues();

        displayMaxValues();



        deltaX = Math.abs((lastX - event.values[0]));
        deltaY = Math.abs(lastY - event.values[1]);
        deltaZ = Math.abs(lastZ - event.values[2]);





    }


    public void displayCleanValues() {
        currentX.setText("0.0");
        currentY.setText("0.0");
        currentZ.setText("0.0");
    }


    public void displayCurrentValues() {
        currentX.setText(Float.toString(deltaX));
        currentY.setText(Float.toString(deltaY));
        currentZ.setText(Float.toString(deltaZ));

    }

    int x = 0;
    int y = 0;
    int z = 0;


    public void displayMaxValues() {
        Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        if (deltaX > deltaXMax) {
            deltaXMax = deltaX;
            alert.setText("Please go back to sleep !!");
            maxX.setText(Float.toString(deltaXMax));
            v.vibrate(500);
            x++;

        }
        if (deltaY > deltaYMax) {
            deltaYMax = deltaY;
            alert.setText("Please go back to sleep !!");

            maxY.setText(Float.toString(deltaYMax));
            y++;
            v.vibrate(500);

        }
        if (deltaZ > deltaZMax) {
            deltaZMax = deltaZ;
            alert.setText("Please go back to sleep !!");

            maxZ.setText(Float.toString(deltaZMax));
            z++;
            v.vibrate(500);

        }



    }


}

