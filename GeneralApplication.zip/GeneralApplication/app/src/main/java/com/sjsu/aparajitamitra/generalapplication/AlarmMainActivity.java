package com.sjsu.aparajitamitra.generalapplication;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.ToggleButton;

import java.text.SimpleDateFormat;
import java.util.Calendar;


public class AlarmMainActivity extends Activity {

    AlarmManager alarmManager;
    private PendingIntent pendingIntent;
    private TimePicker alarmTimePicker;
    private static AlarmMainActivity inst;
    private TextView alarmStatus;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    ToggleButton alarmToggle;

    public static AlarmMainActivity instance() {
        return inst;
    }

    @Override
    public void onStart() {
        super.onStart();
        inst = this;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm);
        sharedPreferences = this.getSharedPreferences("com.sjsu.aparajitamitra.generalapplication",this.MODE_PRIVATE);
        alarmToggle = (ToggleButton) findViewById(R.id.alarmToggle);
        alarmToggle.setChecked(sharedPreferences.getBoolean("alarmToggle",false));
        alarmTimePicker = (TimePicker) findViewById(R.id.alarmTimePicker);
        alarmStatus = (TextView) findViewById(R.id.alarmStatus);
        alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);

    }

    public void onToggleClicked(View view) {
        if(alarmToggle.isChecked()){
            editor = sharedPreferences.edit();
            editor.putBoolean("alarmToggle",true);
            editor.commit();
        }
        else {
            editor = sharedPreferences.edit();
            editor.putBoolean("alarmToggle",false);
            editor.commit();
        }

        if (sharedPreferences.getBoolean("alarmToggle",true)) {
            Log.d("MyActivity", "Alarm On");
            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.HOUR_OF_DAY, alarmTimePicker.getCurrentHour());
            calendar.set(Calendar.MINUTE, alarmTimePicker.getCurrentMinute());
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
            alarmStatus.setText("Alarm Set For: " + sdf.format(calendar.getTime()));
            Intent myIntent = new Intent(AlarmMainActivity.this, AlarmReceiver.class);
            pendingIntent = PendingIntent.getBroadcast(AlarmMainActivity.this, 0, myIntent, 0);
            alarmManager.setExact(AlarmManager.RTC, calendar.getTimeInMillis(), pendingIntent);
        } else {
            alarmManager.cancel(pendingIntent);
            Intent stopIntent = new Intent(this, AlarmService.class);
            this.stopService(stopIntent);
            alarmStatus.setText("Alarm Set For: ");
            Log.d("MyActivity", "Alarm Off");
        }
    }

    public void turnOffAlarm(View view){
        Intent stopIntent = new Intent(this, AlarmService.class);
        this.stopService(stopIntent);
    }


}
