package com.sjsu.aparajitamitra.generalapplication;




import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;


public class ApplicationEx extends android.app.Application {

    public static final CharSequence[] flag_options = {"BIND_AUTO_CREATE",
            "BIND_ADJUST_WITH_ACTIVITY"};
    public static Context context;
    public static String dataType;
    public static String fileExtension;
    public static int selectedFlag = 0;



    public static boolean isConnectionAvailable(Context context) {
        ConnectivityManager conn = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo wifiNetwork = conn
                .getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        NetworkInfo mobileNetwork = conn
                .getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        if (wifiNetwork != null && wifiNetwork.isAvailable() == true
                && wifiNetwork.isConnectedOrConnecting() == true) {
            return true;
        } else if (mobileNetwork != null && mobileNetwork.isAvailable() == true
                && mobileNetwork.isConnectedOrConnecting() == true) {
            return true;
        } else
            return false;
    }


    public static void showDialog(Context context) {
        AlertDialog.Builder dialog = new AlertDialog.Builder(
                context);
        dialog.setTitle(context.getResources().getString(
                R.string.flag_bind_adjust));
        dialog.setMessage(context.getResources().getString(
                R.string.flag_bind_adjust_message));
        dialog.setCancelable(false);
        dialog.setPositiveButton(android.R.string.ok,
                new DialogInterface.OnClickListener() {
                    public void onClick(
                            DialogInterface dialog,
                            int whichButton) {
                        dialog.dismiss();
                    }
                });
        dialog.show();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        context = getApplicationContext();

    }
}

