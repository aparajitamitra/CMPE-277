package com.sjsu.aparajitamitra.generalapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {


    Button map, service;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button launchWebsite = (Button) findViewById(R.id.runWebsite);
        btnListener();

        launchWebsite.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                Uri uri = Uri.parse("http://www.google.com"); // missing 'http://' will cause crashed
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);

            }
        });
    }

    public void btnListener() {

        final Context context = this;

        Button sensor = (Button) findViewById(R.id.button);
        Button map = (Button) findViewById(R.id.map);

        Button fall = (Button) findViewById(R.id.service);

        Button btnAlarm = (Button) findViewById(R.id.btnAlarm);
        btnAlarm.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                //open Alarm Activity
                Intent intent = new Intent(context, AlarmMainActivity.class);
                startActivityFromChild((Activity) context, intent, 1);

            }
        });


        sensor.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                //open Sensor Activity
                Intent intent = new Intent(context, Sensors.class);
                startActivityFromChild((Activity) context, intent, 1);


            }
        });

        map.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                //open Google Map Activity
                Intent intent = new Intent(context, MapsActivity.class);
                startActivityFromChild((Activity) context, intent, 1);


            }
        });

        fall.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                //open Google Map Activity
                Intent intent = new Intent(getApplicationContext(), FallMainActivity.class);
                startActivity(intent);


            }
        });



    }
}
